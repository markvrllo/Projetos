Arquivo zip gerado em: 17/06/2025 21:38:26 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Simulado: 04 Análise de Histórico Escolar
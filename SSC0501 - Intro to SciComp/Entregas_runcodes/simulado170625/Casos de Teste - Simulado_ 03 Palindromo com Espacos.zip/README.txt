Arquivo zip gerado em: 17/06/2025 21:39:55 
Este arquivo contém os casos de teste cadastrados até o momento, disponibilizado pelo professor aos alunos.
Exercício: Simulado: 03 Palíndromo com Espaços